globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/5QCPXpNTnWYT6t731p8P-/_buildManifest.js",
    "static/5QCPXpNTnWYT6t731p8P-/_ssgManifest.js",
    "static/5QCPXpNTnWYT6t731p8P-/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1kkdakf80rggw.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/34r1id01qvimw.js",
    "static/chunks/11oof8oxnxiv9.js",
    "static/chunks/turbopack-26sjlckjmul7m.js"
  ]
};
