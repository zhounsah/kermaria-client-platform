globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/objw_2lEYbql8e06B8YI9/_buildManifest.js",
    "static/objw_2lEYbql8e06B8YI9/_ssgManifest.js",
    "static/objw_2lEYbql8e06B8YI9/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1kkdakf80rggw.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/34r1id01qvimw.js",
    "static/chunks/11oof8oxnxiv9.js",
    "static/chunks/turbopack-26sjlckjmul7m.js"
  ]
};
