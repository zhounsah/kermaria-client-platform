module.exports=[21095,(a,b,c)=>{}];

//# sourceMappingURL=11o0_next-internal_server_app_admin_editorial_%5BcontentType%5D_new_page_actions_0udprmp.js.map