module.exports=[68485,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_profile_route_actions_09fuvo_.js.map