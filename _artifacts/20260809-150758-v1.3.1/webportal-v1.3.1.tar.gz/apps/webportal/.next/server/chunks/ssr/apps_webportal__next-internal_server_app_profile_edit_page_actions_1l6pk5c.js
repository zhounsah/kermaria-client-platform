module.exports=[79634,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_profile_edit_page_actions_1l6pk5c.js.map