module.exports=[52846,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_admin_editorial_%5BcontentType%5D_page_actions_1tup-ar.js.map