module.exports=[24141,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_backups_integrations_route_actions_0b9ksvr.js.map