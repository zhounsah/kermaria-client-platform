module.exports=[55512,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_editorial_%5Bid%5D_route_actions_1qi3yoo.js.map