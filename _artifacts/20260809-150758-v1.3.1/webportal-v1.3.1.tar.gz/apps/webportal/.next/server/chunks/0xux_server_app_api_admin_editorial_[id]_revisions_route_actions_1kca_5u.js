module.exports=[36903,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_editorial_%5Bid%5D_revisions_route_actions_1kca_5u.js.map