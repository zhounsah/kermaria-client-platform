module.exports=[37543,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_editorial_categories_route_actions_02szxum.js.map