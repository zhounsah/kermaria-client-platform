module.exports=[99916,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_demo_page_actions_0x64xwd.js.map