module.exports=[14728,(e,o,d)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_api_admin_editorial_route_actions_0qb6wav.js.map