module.exports=[71015,(a,b,c)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_admin_solutions_new_page_actions_0qdcxp0.js.map