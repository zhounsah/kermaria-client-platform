module.exports=[20510,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_editorial_categories_%5Bid%5D_route_actions_0873sbo.js.map