module.exports=[56192,(a,b,c)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_wiki_categorie_%5Bslug%5D_page_actions_0f2coze.js.map