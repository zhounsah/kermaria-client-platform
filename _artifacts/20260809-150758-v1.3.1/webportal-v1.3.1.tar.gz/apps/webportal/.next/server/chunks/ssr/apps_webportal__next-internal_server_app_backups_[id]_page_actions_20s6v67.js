module.exports=[2341,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_backups_%5Bid%5D_page_actions_20s6v67.js.map