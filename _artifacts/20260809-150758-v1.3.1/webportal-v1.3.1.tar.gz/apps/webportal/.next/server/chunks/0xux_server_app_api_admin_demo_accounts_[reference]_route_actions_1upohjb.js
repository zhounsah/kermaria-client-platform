module.exports=[66532,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_demo_accounts_%5Breference%5D_route_actions_1upohjb.js.map