module.exports=[50777,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_solutions_page_actions_0sh6h3g.js.map