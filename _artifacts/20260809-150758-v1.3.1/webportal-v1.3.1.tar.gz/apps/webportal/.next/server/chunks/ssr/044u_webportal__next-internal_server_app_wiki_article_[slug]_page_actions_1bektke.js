module.exports=[29403,(a,b,c)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_wiki_article_%5Bslug%5D_page_actions_1bektke.js.map