module.exports=[72222,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_backups_page_actions_1z2gufs.js.map