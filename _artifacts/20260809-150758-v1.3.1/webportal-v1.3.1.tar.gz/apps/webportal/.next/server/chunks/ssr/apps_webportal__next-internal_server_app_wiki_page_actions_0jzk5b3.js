module.exports=[45823,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_wiki_page_actions_0jzk5b3.js.map