module.exports=[68751,(a,b,c)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_admin_demo_profiles_page_actions_14fy4jv.js.map