module.exports=[82920,(a,b,c)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_admin_solutions_%5Bid%5D_page_actions_1le87gz.js.map