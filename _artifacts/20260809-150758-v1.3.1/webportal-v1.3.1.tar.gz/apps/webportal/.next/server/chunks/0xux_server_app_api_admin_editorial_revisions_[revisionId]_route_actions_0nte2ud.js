module.exports=[77294,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_editorial_revisions_%5BrevisionId%5D_route_actions_0nte2ud.js.map