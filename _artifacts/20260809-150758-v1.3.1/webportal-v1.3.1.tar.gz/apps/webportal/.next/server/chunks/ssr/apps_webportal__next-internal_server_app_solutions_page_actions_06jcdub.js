module.exports=[1426,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_solutions_page_actions_06jcdub.js.map