module.exports=[37590,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_backups_%5Bid%5D_restore-requests_route_actions_1mp4k-0.js.map