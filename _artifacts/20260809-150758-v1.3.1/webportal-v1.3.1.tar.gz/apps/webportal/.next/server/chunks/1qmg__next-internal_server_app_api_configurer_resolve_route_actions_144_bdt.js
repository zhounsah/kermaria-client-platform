module.exports=[61753,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_configurer_resolve_route_actions_144_bdt.js.map