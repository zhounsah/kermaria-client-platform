module.exports=[75259,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_client-solutions_%5Bid%5D_logo_route_actions_1by9zw1.js.map