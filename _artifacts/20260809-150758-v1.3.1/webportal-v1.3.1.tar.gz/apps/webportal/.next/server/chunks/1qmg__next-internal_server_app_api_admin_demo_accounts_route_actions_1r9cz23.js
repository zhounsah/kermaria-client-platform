module.exports=[72026,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_demo_accounts_route_actions_1r9cz23.js.map