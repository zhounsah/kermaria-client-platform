module.exports=[17854,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_configurer_page_actions_1f-6i91.js.map