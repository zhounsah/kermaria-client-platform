module.exports=[13365,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_koxo_validate_route_actions_0zatmf0.js.map