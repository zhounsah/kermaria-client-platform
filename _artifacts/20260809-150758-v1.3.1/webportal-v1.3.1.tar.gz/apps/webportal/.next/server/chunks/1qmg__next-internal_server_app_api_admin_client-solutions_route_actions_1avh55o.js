module.exports=[35444,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_client-solutions_route_actions_1avh55o.js.map