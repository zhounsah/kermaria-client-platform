module.exports=[85850,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_client-solutions_settings_route_actions_0c8hu28.js.map