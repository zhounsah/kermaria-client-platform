module.exports=[20348,(e,o,d)=>{}];

//# sourceMappingURL=11o0_next-internal_server_app_api_admin_editorial_%5Bid%5D_publish_route_actions_1jabezs.js.map