module.exports=[41833,(e,o,d)=>{}];

//# sourceMappingURL=11o0_next-internal_server_app_api_admin_editorial_%5Bid%5D_archive_route_actions_1uza1c1.js.map