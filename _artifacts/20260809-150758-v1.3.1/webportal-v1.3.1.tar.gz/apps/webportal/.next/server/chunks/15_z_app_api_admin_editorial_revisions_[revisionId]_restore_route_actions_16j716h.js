module.exports=[38861,(e,o,d)=>{}];

//# sourceMappingURL=15_z_app_api_admin_editorial_revisions_%5BrevisionId%5D_restore_route_actions_16j716h.js.map