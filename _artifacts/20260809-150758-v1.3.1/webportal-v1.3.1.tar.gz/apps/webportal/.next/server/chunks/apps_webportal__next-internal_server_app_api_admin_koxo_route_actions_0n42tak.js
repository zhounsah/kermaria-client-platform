module.exports=[42045,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_admin_koxo_route_actions_0n42tak.js.map