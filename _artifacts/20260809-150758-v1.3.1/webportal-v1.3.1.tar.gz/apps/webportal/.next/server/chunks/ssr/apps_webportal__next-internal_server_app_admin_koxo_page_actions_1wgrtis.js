module.exports=[21648,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_koxo_page_actions_1wgrtis.js.map