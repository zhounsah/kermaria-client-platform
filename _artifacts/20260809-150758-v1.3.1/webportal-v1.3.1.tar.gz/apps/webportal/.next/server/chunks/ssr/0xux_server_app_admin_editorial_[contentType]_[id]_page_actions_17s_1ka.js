module.exports=[96095,(a,b,c)=>{}];

//# sourceMappingURL=0xux_server_app_admin_editorial_%5BcontentType%5D_%5Bid%5D_page_actions_17s_1ka.js.map