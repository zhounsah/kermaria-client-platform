module.exports=[22277,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_demo_profiles_route_actions_0_uwbmh.js.map