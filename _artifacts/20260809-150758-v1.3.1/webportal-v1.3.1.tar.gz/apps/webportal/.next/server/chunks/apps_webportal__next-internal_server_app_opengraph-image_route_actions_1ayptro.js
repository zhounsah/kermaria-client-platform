module.exports=[20711,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_opengraph-image_route_actions_1ayptro.js.map