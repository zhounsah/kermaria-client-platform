module.exports=[3582,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_solutions_%5Bid%5D_logo_route_actions_0q5zb86.js.map