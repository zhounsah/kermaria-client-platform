module.exports=[90365,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_internal_koxo_users_route_actions_1aoxq-v.js.map