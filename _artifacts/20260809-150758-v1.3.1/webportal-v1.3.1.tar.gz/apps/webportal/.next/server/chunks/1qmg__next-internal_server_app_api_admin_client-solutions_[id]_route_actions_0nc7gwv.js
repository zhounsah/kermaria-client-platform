module.exports=[55823,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_client-solutions_%5Bid%5D_route_actions_0nc7gwv.js.map