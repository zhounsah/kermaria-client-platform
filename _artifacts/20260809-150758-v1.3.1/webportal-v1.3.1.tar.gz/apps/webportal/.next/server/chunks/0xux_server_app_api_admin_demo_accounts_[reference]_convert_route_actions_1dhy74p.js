module.exports=[11336,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_demo_accounts_%5Breference%5D_convert_route_actions_1dhy74p.js.map