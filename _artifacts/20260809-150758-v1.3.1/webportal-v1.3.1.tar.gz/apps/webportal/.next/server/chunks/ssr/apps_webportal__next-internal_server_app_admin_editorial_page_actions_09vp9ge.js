module.exports=[96675,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_editorial_page_actions_09vp9ge.js.map