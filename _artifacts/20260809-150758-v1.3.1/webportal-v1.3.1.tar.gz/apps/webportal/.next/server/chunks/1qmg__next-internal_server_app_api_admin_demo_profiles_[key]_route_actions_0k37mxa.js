module.exports=[49055,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_demo_profiles_%5Bkey%5D_route_actions_0k37mxa.js.map