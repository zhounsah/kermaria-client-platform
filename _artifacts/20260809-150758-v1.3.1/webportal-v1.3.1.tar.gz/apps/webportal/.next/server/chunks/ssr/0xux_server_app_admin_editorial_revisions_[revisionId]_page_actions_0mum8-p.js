module.exports=[78386,(a,b,c)=>{}];

//# sourceMappingURL=0xux_server_app_admin_editorial_revisions_%5BrevisionId%5D_page_actions_0mum8-p.js.map