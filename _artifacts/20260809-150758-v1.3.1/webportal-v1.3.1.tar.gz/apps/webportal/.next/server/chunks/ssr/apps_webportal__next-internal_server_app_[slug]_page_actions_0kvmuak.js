module.exports=[97979,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_%5Bslug%5D_page_actions_0kvmuak.js.map