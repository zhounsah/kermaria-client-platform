using System.Text.Json;
using Kermaria.ApiInternal;
using Kermaria.ApiInternal.Contracts;
using Kermaria.ApiInternal.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.ClearProviders();
builder.Logging.AddJsonConsole(options =>
{
    options.IncludeScopes = true;
    options.TimestampFormat = "yyyy-MM-ddTHH:mm:ss.fffZ";
    options.UseUtcTimestamp = true;
});

var app = builder.Build();

app.UseMiddleware<CorrelationIdMiddleware>();

app.UseExceptionHandler(exceptionHandler =>
{
    exceptionHandler.Run(async context =>
    {
        var correlationId = context.GetCorrelationId();

        app.Logger.LogError(
            "Unhandled request failure with correlation_id {CorrelationId}",
            correlationId);

        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        await context.Response.WriteAsJsonAsync(new ApiError(
            "INTERNAL_ERROR",
            "Une erreur interne est survenue.",
            correlationId));
    });
});

app.MapGet("/health", () =>
    Results.Ok(new HealthResponse("ok", ServiceNames.ApiInternal)));

// Routes métier temporaires strictement mock. Elles ne consultent ni SQL,
// ni Active Directory, ni facturation, et ne persistent aucune donnée.
app.MapGet("/internal/portal/summary", () => Results.Ok(MockPortalData.Summary));
app.MapGet("/internal/portal/profile", () => Results.Ok(MockPortalData.Profile));
app.MapGet("/internal/portal/services", () => Results.Ok(MockPortalData.Services));
app.MapGet("/internal/portal/invoices", () => Results.Ok(MockPortalData.Invoices));
app.MapGet(
    "/internal/portal/service-catalog",
    () => Results.Ok(MockPortalData.ServiceCatalog));
app.MapGet(
    "/internal/portal/support-requests",
    () => Results.Ok(MockPortalData.SupportRequests));
app.MapPost(
    "/internal/portal/support-requests",
    CreateMockSupportRequest);
app.MapPost(
    "/internal/portal/service-requests",
    CreateMockServiceRequest);

// L'intégration Active Directory réelle est interdite pendant la phase actuelle.
// Ces routes ne lisent pas les corps, ne manipulent aucun mot de passe et
// retournent uniquement un refus mock contrôlé et corrélé.
app.MapPost("/internal/ad/change-password", MockAdOperation);
app.MapPost("/internal/ad/create-user", MockAdOperation);
app.MapPost("/internal/ad/add-user-to-group", MockAdOperation);
app.MapPost("/internal/ad/remove-user-from-group", MockAdOperation);

app.MapFallback((HttpContext context) =>
    Results.Json(
        new ApiError(
            "ROUTE_NOT_FOUND",
            "La ressource demandée est introuvable.",
            context.GetCorrelationId()),
        statusCode: StatusCodes.Status404NotFound));

app.Run();

static async Task<IResult> CreateMockSupportRequest(
    HttpContext context,
    ILogger<Program> logger)
{
    var payload = await ReadPayload<SupportRequestPayload>(context);

    if (payload is null
        || string.IsNullOrWhiteSpace(payload.ServiceId)
        || string.IsNullOrWhiteSpace(payload.Subject)
        || string.IsNullOrWhiteSpace(payload.Description)
        || payload.Subject.Length > 160
        || payload.Description.Length > 4000
        || payload.Priority is not ("low" or "normal" or "high"))
    {
        return InvalidMockRequest(context);
    }

    logger.LogInformation(
        "Mock support request accepted without persistence; correlation_id {CorrelationId}",
        context.GetCorrelationId());

    return Results.Json(
        new MockSubmissionResponse(
            $"SUP-MOCK-{Guid.NewGuid():N}"[..22].ToUpperInvariant(),
            "mock_received",
            false,
            "Demande mock reçue. Aucune donnée n'a été persistée.",
            context.GetCorrelationId()),
        statusCode: StatusCodes.Status202Accepted);
}

static async Task<IResult> CreateMockServiceRequest(
    HttpContext context,
    ILogger<Program> logger)
{
    var payload = await ReadPayload<ServiceRequestPayload>(context);

    if (payload is null
        || string.IsNullOrWhiteSpace(payload.ServiceId)
        || string.IsNullOrWhiteSpace(payload.Context)
        || payload.Context.Length > 4000
        || payload.Timeline is not ("exploration" or "month" or "quarter"))
    {
        return InvalidMockRequest(context);
    }

    logger.LogInformation(
        "Mock service request accepted without persistence; correlation_id {CorrelationId}",
        context.GetCorrelationId());

    return Results.Json(
        new MockSubmissionResponse(
            $"SRV-MOCK-{Guid.NewGuid():N}"[..22].ToUpperInvariant(),
            "mock_received",
            false,
            "Demande de service mock reçue. Aucun devis ni paiement n'a été créé.",
            context.GetCorrelationId()),
        statusCode: StatusCodes.Status202Accepted);
}

static async Task<T?> ReadPayload<T>(HttpContext context)
{
    try
    {
        return await context.Request.ReadFromJsonAsync<T>();
    }
    catch (JsonException)
    {
        return default;
    }
    catch (NotSupportedException)
    {
        return default;
    }
}

static IResult InvalidMockRequest(HttpContext context)
{
    return Results.Json(
        new ApiError(
            "INVALID_REQUEST",
            "La demande mock est incomplète ou invalide.",
            context.GetCorrelationId()),
        statusCode: StatusCodes.Status400BadRequest);
}

static IResult MockAdOperation(HttpContext context, ILogger<Program> logger)
{
    var correlationId = context.GetCorrelationId();

    logger.LogWarning(
        "Mock AD operation refused for {Path}; no directory action was performed",
        context.Request.Path);

    return Results.Json(
        new ApiError(
            "AD_INTEGRATION_DISABLED",
            "L'intégration Active Directory réelle n'est pas encore activée.",
            correlationId),
        statusCode: StatusCodes.Status501NotImplemented);
}

public partial class Program
{
}
