"use client";

import type {
  ApiError,
  MockSubmissionResponse,
  ServiceSummary,
  SupportRequestPayload,
} from "@kermaria/shared";
import { useState } from "react";

type SupportRequestFormProps = {
  services: ServiceSummary[];
};

type SubmissionState =
  | { status: "idle" | "submitting" }
  | { status: "success"; result: MockSubmissionResponse }
  | { status: "error"; message: string };

export function SupportRequestForm({
  services,
}: SupportRequestFormProps) {
  const [submission, setSubmission] = useState<SubmissionState>({
    status: "idle",
  });

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmission({ status: "submitting" });

    const form = event.currentTarget;
    const formData = new FormData(form);
    const payload: SupportRequestPayload = {
      serviceId: String(formData.get("serviceId") ?? ""),
      priority: String(formData.get("priority") ?? "normal") as
        SupportRequestPayload["priority"],
      subject: String(formData.get("subject") ?? ""),
      description: String(formData.get("description") ?? ""),
    };

    try {
      const response = await fetch("/api/support-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const error = (await response.json()) as ApiError;
        setSubmission({
          status: "error",
          message: error.message || "La simulation n'a pas pu être traitée.",
        });
        return;
      }

      const result = (await response.json()) as MockSubmissionResponse;
      form.reset();
      setSubmission({ status: "success", result });
    } catch {
      setSubmission({
        status: "error",
        message: "La simulation est temporairement indisponible.",
      });
    }
  }

  return (
    <form className="form-card" onSubmit={handleSubmit}>
      {submission.status === "success" ? (
        <div className="feedback-message" role="status">
          <strong>Demande mock reçue.</strong>
          <span>
            Référence {submission.result.reference}. Aucune donnée n&apos;a été
            persistée ni envoyée par e-mail.
          </span>
        </div>
      ) : null}
      {submission.status === "error" ? (
        <div className="feedback-message feedback-error" role="alert">
          <strong>Simulation non envoyée.</strong>
          <span>{submission.message}</span>
        </div>
      ) : null}

      <div className="form-grid">
        <label>
          Service concerné
          <select name="serviceId" required>
            <option value="">Sélectionner un service</option>
            {services.map((service) => (
              <option key={service.id} value={service.id}>
                {service.name}
              </option>
            ))}
            <option value="account">Compte client</option>
          </select>
        </label>
        <label>
          Priorité
          <select defaultValue="normal" name="priority">
            <option value="low">Faible</option>
            <option value="normal">Normale</option>
            <option value="high">Haute</option>
          </select>
        </label>
      </div>

      <label>
        Objet
        <input
          autoComplete="off"
          maxLength={160}
          name="subject"
          placeholder="Ex. Vérification d'une sauvegarde"
          required
          type="text"
        />
      </label>

      <label>
        Description
        <textarea
          maxLength={4000}
          name="description"
          placeholder="Décrivez le contexte. Ne saisissez aucun identifiant, mot de passe ou contenu confidentiel."
          required
          rows={6}
        />
      </label>

      <div className="form-footer">
        <p className="form-helper">
          Démonstration uniquement : aucun ticket réel, e-mail ou enregistrement.
        </p>
        <button
          className="button"
          disabled={submission.status === "submitting"}
          type="submit"
        >
          {submission.status === "submitting"
            ? "Simulation en cours..."
            : "Simuler l'envoi"}
        </button>
      </div>
    </form>
  );
}
