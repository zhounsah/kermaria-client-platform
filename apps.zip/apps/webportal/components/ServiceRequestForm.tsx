"use client";

import type {
  ApiError,
  MockSubmissionResponse,
  ServiceCatalogItem,
  ServiceRequestPayload,
} from "@kermaria/shared";
import { useState } from "react";

type ServiceRequestFormProps = {
  services: ServiceCatalogItem[];
};

type SubmissionState =
  | { status: "idle" | "submitting" }
  | { status: "success"; result: MockSubmissionResponse }
  | { status: "error"; message: string };

export function ServiceRequestForm({
  services,
}: ServiceRequestFormProps) {
  const [submission, setSubmission] = useState<SubmissionState>({
    status: "idle",
  });

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmission({ status: "submitting" });

    const form = event.currentTarget;
    const formData = new FormData(form);
    const payload: ServiceRequestPayload = {
      serviceId: String(formData.get("serviceId") ?? ""),
      timeline: String(formData.get("timeline") ?? "exploration") as
        ServiceRequestPayload["timeline"],
      context: String(formData.get("context") ?? ""),
    };

    try {
      const response = await fetch("/api/service-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const error = (await response.json()) as ApiError;
        setSubmission({
          status: "error",
          message: error.message || "La simulation n'a pas pu être traitée.",
        });
        return;
      }

      const result = (await response.json()) as MockSubmissionResponse;
      form.reset();
      setSubmission({ status: "success", result });
    } catch {
      setSubmission({
        status: "error",
        message: "La simulation est temporairement indisponible.",
      });
    }
  }

  return (
    <form className="form-card" onSubmit={handleSubmit}>
      {submission.status === "success" ? (
        <div className="feedback-message" role="status">
          <strong>Demande de service mock reçue.</strong>
          <span>
            Référence {submission.result.reference}. Aucun devis, contrat ou
            paiement n&apos;a été créé.
          </span>
        </div>
      ) : null}
      {submission.status === "error" ? (
        <div className="feedback-message feedback-error" role="alert">
          <strong>Simulation non envoyée.</strong>
          <span>{submission.message}</span>
        </div>
      ) : null}

      <div className="form-grid">
        <label>
          Service souhaité
          <select name="serviceId" required>
            <option value="">Sélectionner une prestation</option>
            {services.map((service) => (
              <option key={service.id} value={service.id}>
                {service.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Échéance souhaitée
          <select defaultValue="exploration" name="timeline">
            <option value="exploration">Étude du besoin</option>
            <option value="month">Dans le mois</option>
            <option value="quarter">Dans le trimestre</option>
          </select>
        </label>
      </div>

      <label>
        Contexte de la demande
        <textarea
          maxLength={4000}
          name="context"
          placeholder="Précisez le besoin sans inclure d'identifiants, mots de passe ou données confidentielles."
          required
          rows={6}
        />
      </label>

      <div className="form-footer">
        <p className="form-helper">
          Cette V0.5 ne crée ni commande, ni contrat, ni paiement.
        </p>
        <button
          className="button"
          disabled={submission.status === "submitting"}
          type="submit"
        >
          {submission.status === "submitting"
            ? "Simulation en cours..."
            : "Simuler la demande"}
        </button>
      </div>
    </form>
  );
}
