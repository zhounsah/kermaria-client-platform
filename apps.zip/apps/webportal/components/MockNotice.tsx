import type { CorrelationId, DataSource } from "@kermaria/shared";

type MockNoticeProps = {
  source: DataSource;
  correlationId?: CorrelationId;
};

export function MockNotice({
  source,
  correlationId,
}: MockNoticeProps) {
  if (source === "unavailable") {
    return (
      <div className="demo-notice demo-notice-error" role="status">
        <strong>Données indisponibles</strong>
        <span>
          La source mock n&apos;a pas pu être jointe. Aucun détail technique
          n&apos;est affiché.
          {correlationId ? ` Référence : ${correlationId}.` : ""}
        </span>
      </div>
    );
  }

  return (
    <div className="demo-notice">
      <strong>Mode démonstration</strong>
      <span>
        {source === "api-internal-mock"
          ? "Données fournies côté serveur par API-INTERNAL en mode mock, sans persistance."
          : "Fallback local de développement actif, sans appel à un système réel."}
      </span>
    </div>
  );
}
