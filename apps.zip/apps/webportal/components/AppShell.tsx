import Link from "next/link";
import type { ReactNode } from "react";

import { PortalNavigation } from "@/components/PortalNavigation";

type AppShellProps = {
  children: ReactNode;
};

export function AppShell({ children }: AppShellProps) {
  return (
    <>
      <header className="site-header">
        <div className="site-header-inner">
          <Link className="brand" href="/">
            <span className="brand-mark" aria-hidden="true">
              ZH
            </span>
            <span className="brand-copy">
              <strong>Zachary HOUNSA-HOUNKPA EI</strong>
              <small>Espace client</small>
            </span>
          </Link>
          <div className="demo-chip">Démonstration V0.5</div>
        </div>
      </header>
      <PortalNavigation />
      <main className="main-content">{children}</main>
      <footer className="site-footer">
        <div>
          <strong>Zachary HOUNSA-HOUNKPA EI</strong>
          <p>Espace client de démonstration, données fictives.</p>
        </div>
        <p>Aucune intégration AD, SQL, facturation ou paiement.</p>
      </footer>
    </>
  );
}
