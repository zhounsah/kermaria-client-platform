import { EmptyState } from "@/components/EmptyState";
import { FormSection } from "@/components/FormSection";
import { MockNotice } from "@/components/MockNotice";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { SupportRequestForm } from "@/components/SupportRequestForm";
import { formatDate, supportStatus } from "@/lib/formatters";
import {
  getServices,
  getSupportRequests,
  resolveDataSource,
} from "@/lib/internal-api";

export const metadata = {
  title: "Support",
};

export const dynamic = "force-dynamic";

const priorityLabels = {
  low: "Faible",
  normal: "Normale",
  high: "Haute",
};

export default async function SupportPage() {
  const [requestsResult, servicesResult] = await Promise.all([
    getSupportRequests(),
    getServices(),
  ]);
  const source = resolveDataSource([
    requestsResult.source,
    servicesResult.source,
  ]);

  return (
    <>
      <PageHeader
        action={<StatusBadge label="Formulaire mock" tone="info" />}
        description="Aucune demande réelle, aucun e-mail et aucune écriture en base ne sont effectués dans cette V0.5."
        eyebrow="Assistance"
        title="Demandes de support"
      />

      <div className="support-layout">
        <FormSection
          description="La validation passe uniquement par une route BFF du portail et une réponse mock non persistante."
          title="Nouvelle demande fictive"
        >
          <SupportRequestForm services={servicesResult.data} />
        </FormSection>

        <section>
          <div className="section-heading">
            <div>
              <h2>Demandes récentes</h2>
              <p>Historique fictif de démonstration.</p>
            </div>
          </div>
          {requestsResult.data.length === 0 ? (
            <EmptyState
              description="Aucune demande support mock n'est disponible."
              title="Aucune demande"
            />
          ) : (
            <div className="ticket-list">
              {requestsResult.data.map((request) => {
                const status = supportStatus[request.status];

                return (
                  <article className="ticket-card" key={request.id}>
                    <div className="ticket-card-header">
                      <span className="card-kicker">{request.reference}</span>
                      <StatusBadge label={status.label} tone={status.tone} />
                    </div>
                    <h3>{request.subject}</h3>
                    <p>{request.serviceName}</p>
                    <div className="ticket-meta">
                      <span>Priorité {priorityLabels[request.priority]}</span>
                      <span>Mis à jour le {formatDate(request.updatedAt)}</span>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </div>

      <MockNotice
        correlationId={requestsResult.correlationId}
        source={source}
      />
    </>
  );
}
