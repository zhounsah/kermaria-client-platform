import type { ApiError, ServiceRequestPayload } from "@kermaria/shared";
import { NextRequest, NextResponse } from "next/server";

import { CORRELATION_HEADER, resolveCorrelationId } from "@/lib/correlation";
import {
  createServiceRequest,
  getInternalApiError,
} from "@/lib/internal-api";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const correlationId = resolveCorrelationId(
    request.headers.get(CORRELATION_HEADER),
  );

  let payload: ServiceRequestPayload;

  try {
    payload = (await request.json()) as ServiceRequestPayload;
  } catch {
    return invalidRequest(correlationId);
  }

  if (
    !payload.serviceId
    || !payload.context
    || payload.context.length > 4000
    || !["exploration", "month", "quarter"].includes(payload.timeline)
  ) {
    return invalidRequest(correlationId);
  }

  try {
    const result = await createServiceRequest(payload, correlationId);
    const response = NextResponse.json(result, { status: 202 });

    response.headers.set(CORRELATION_HEADER, result.correlation_id);

    return response;
  } catch (error) {
    const failure = getInternalApiError(error);
    const response = NextResponse.json(failure.error, {
      status: failure.status,
    });

    response.headers.set(
      CORRELATION_HEADER,
      failure.error.correlation_id,
    );

    return response;
  }
}

function invalidRequest(correlationId: ApiError["correlation_id"]) {
  const error: ApiError = {
    code: "INVALID_REQUEST",
    message: "La demande mock est incomplète ou invalide.",
    correlation_id: correlationId,
  };
  const response = NextResponse.json(error, { status: 400 });

  response.headers.set(CORRELATION_HEADER, correlationId);

  return response;
}
