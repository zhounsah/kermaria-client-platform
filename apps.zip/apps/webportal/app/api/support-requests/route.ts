import type { ApiError, SupportRequestPayload } from "@kermaria/shared";
import { NextRequest, NextResponse } from "next/server";

import { CORRELATION_HEADER, resolveCorrelationId } from "@/lib/correlation";
import {
  createSupportRequest,
  getInternalApiError,
} from "@/lib/internal-api";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const correlationId = resolveCorrelationId(
    request.headers.get(CORRELATION_HEADER),
  );

  let payload: SupportRequestPayload;

  try {
    payload = (await request.json()) as SupportRequestPayload;
  } catch {
    return invalidRequest(correlationId);
  }

  if (
    !payload.serviceId
    || !payload.subject
    || !payload.description
    || payload.subject.length > 160
    || payload.description.length > 4000
    || !["low", "normal", "high"].includes(payload.priority)
  ) {
    return invalidRequest(correlationId);
  }

  try {
    const result = await createSupportRequest(payload, correlationId);
    const response = NextResponse.json(result, { status: 202 });

    response.headers.set(CORRELATION_HEADER, result.correlation_id);

    return response;
  } catch (error) {
    const failure = getInternalApiError(error);
    const response = NextResponse.json(failure.error, {
      status: failure.status,
    });

    response.headers.set(
      CORRELATION_HEADER,
      failure.error.correlation_id,
    );

    return response;
  }
}

function invalidRequest(correlationId: ApiError["correlation_id"]) {
  const error: ApiError = {
    code: "INVALID_REQUEST",
    message: "La demande mock est incomplète ou invalide.",
    correlation_id: correlationId,
  };
  const response = NextResponse.json(error, { status: 400 });

  response.headers.set(CORRELATION_HEADER, correlationId);

  return response;
}
