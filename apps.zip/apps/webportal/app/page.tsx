import Link from "next/link";

export default function HomePage() {
  return (
    <section className="landing">
      <div className="landing-copy">
        <p className="eyebrow">Zachary HOUNSA-HOUNKPA EI</p>
        <h1>Vos services et demandes réunis dans un espace client clair.</h1>
        <p className="lead">
          Consultez une démonstration de vos services, factures fictives et
          demandes d&apos;assistance depuis une interface unique.
        </p>
        <div className="actions">
          <Link className="button" href="/dashboard">
            Accéder à la démonstration
          </Link>
          <Link className="button button-secondary" href="/request-service">
            Découvrir les services
          </Link>
        </div>
        <p className="landing-note">
          V0.5 mock sans authentification réelle, connexion SQL, Active
          Directory, facturation réelle ni paiement.
        </p>
      </div>

      <aside className="landing-preview" aria-label="Aperçu de l'espace client">
        <div className="preview-header">
          <div>
            <span className="preview-kicker">Espace client</span>
            <strong>Atelier Horizon</strong>
          </div>
          <span className="status-badge status-success">Compte mock actif</span>
        </div>
        <div className="preview-metrics">
          <div>
            <span>Services actifs</span>
            <strong>3</strong>
          </div>
          <div>
            <span>Demandes ouvertes</span>
            <strong>2</strong>
          </div>
          <div>
            <span>Facture fictive</span>
            <strong>1</strong>
          </div>
        </div>
        <div className="preview-list">
          <div>
            <span className="preview-icon">HDP</span>
            <p>
              <strong>Hébergement dossier personnel</strong>
              <small>Selon devis</small>
            </p>
          </div>
          <div>
            <span className="preview-icon">SAV</span>
            <p>
              <strong>Sauvegarde dossier personnel</strong>
              <small>Inclus selon périmètre</small>
            </p>
          </div>
        </div>
      </aside>
    </section>
  );
}
