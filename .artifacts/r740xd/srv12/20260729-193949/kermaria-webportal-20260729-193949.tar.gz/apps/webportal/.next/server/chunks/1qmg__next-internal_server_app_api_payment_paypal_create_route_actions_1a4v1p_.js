module.exports=[70506,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_payment_paypal_create_route_actions_1a4v1p_.js.map