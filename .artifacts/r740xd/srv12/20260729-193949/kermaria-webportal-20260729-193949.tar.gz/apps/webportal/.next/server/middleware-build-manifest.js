globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/T4tDZznPLakBfBZMXUUNk/_buildManifest.js",
    "static/T4tDZznPLakBfBZMXUUNk/_ssgManifest.js",
    "static/T4tDZznPLakBfBZMXUUNk/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2-ndo0lbpp9_x.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/07u_h6i539_wj.js",
    "static/chunks/0upz6l02pcet9.js",
    "static/chunks/turbopack-0zxsonpmvzbw3.js"
  ]
};
