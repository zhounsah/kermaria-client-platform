module.exports=[67478,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_panier_page_actions_0y90874.js.map