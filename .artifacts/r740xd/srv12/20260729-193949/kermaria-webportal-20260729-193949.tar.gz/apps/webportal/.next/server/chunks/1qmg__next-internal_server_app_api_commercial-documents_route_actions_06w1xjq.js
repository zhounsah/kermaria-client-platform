module.exports=[83487,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_commercial-documents_route_actions_06w1xjq.js.map