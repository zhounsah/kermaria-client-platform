module.exports=[75952,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_downloads_%5Bid%5D_file_route_actions_1ipm13r.js.map