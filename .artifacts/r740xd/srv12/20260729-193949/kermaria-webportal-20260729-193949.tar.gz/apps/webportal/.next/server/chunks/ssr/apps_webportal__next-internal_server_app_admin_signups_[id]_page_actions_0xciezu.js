module.exports=[50208,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_signups_%5Bid%5D_page_actions_0xciezu.js.map