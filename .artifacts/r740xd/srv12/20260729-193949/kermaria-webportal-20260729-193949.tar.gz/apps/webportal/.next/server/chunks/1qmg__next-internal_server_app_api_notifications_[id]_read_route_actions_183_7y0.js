module.exports=[66685,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_notifications_%5Bid%5D_read_route_actions_183_7y0.js.map