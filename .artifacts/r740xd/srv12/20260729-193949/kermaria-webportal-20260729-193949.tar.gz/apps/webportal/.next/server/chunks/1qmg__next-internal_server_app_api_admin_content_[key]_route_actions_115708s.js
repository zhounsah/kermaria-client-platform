module.exports=[57110,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_content_%5Bkey%5D_route_actions_115708s.js.map