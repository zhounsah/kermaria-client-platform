module.exports=[89755,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_subscriptions_%5Bid%5D_cancel_route_actions_0fowrkz.js.map