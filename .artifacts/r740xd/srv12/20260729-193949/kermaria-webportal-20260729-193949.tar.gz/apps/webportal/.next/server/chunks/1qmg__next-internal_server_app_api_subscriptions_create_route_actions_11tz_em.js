module.exports=[29881,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_subscriptions_create_route_actions_11tz_em.js.map