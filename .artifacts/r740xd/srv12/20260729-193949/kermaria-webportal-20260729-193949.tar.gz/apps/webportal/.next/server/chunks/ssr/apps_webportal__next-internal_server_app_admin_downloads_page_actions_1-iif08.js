module.exports=[24923,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_downloads_page_actions_1-iif08.js.map