module.exports=[35584,(a,b,c)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_admin_downloads_%5Bid%5D_page_actions_11yt7s-.js.map