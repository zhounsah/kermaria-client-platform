module.exports=[92588,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_signups_%5Bid%5D_route_actions_0cehbon.js.map