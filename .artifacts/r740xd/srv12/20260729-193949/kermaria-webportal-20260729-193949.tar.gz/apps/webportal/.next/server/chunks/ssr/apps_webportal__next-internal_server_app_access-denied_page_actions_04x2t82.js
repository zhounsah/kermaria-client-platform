module.exports=[62597,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_access-denied_page_actions_04x2t82.js.map