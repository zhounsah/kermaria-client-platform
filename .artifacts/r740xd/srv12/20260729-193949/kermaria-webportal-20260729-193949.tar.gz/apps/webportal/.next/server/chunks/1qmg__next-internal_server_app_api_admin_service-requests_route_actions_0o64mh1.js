module.exports=[16427,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_service-requests_route_actions_0o64mh1.js.map