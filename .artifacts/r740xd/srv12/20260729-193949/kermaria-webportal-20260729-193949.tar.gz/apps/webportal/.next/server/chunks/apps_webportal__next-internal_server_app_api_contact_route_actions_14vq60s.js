module.exports=[46237,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_contact_route_actions_14vq60s.js.map