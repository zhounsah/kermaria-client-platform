module.exports=[65528,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_souscrire_page_actions_1_h2ong.js.map