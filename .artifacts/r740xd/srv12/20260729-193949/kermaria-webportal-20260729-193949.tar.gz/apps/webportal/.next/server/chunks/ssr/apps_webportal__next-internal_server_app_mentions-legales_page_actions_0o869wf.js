module.exports=[62313,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_mentions-legales_page_actions_0o869wf.js.map