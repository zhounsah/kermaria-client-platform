module.exports=[74913,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app__not-found_page_actions_0dyklgs.js.map