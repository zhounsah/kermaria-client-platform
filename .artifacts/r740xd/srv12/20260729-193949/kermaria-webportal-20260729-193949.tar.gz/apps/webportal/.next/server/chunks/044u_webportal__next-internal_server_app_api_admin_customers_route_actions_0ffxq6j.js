module.exports=[18877,(e,o,d)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_api_admin_customers_route_actions_0ffxq6j.js.map