module.exports=[4423,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_payments_page_actions_1hdtg2z.js.map