var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__1zhbogw._.js")
R.c("server/chunks/[root-of-the-server]__0avi85e._.js")
R.m(1427)
module.exports=R.m(1427).exports
