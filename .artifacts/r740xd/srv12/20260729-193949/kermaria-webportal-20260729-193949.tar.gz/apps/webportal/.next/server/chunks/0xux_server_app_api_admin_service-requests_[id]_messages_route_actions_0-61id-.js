module.exports=[59900,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_service-requests_%5Bid%5D_messages_route_actions_0-61id-.js.map