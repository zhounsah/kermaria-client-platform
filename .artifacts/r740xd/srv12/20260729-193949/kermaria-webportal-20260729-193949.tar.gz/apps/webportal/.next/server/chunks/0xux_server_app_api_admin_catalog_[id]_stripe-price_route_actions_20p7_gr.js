module.exports=[80924,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_catalog_%5Bid%5D_stripe-price_route_actions_20p7_gr.js.map