module.exports=[98791,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_commercial-documents_%5Bid%5D_payment-method_route_actions_0g7-_b8.js.map