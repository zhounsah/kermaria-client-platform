module.exports=[44346,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_public-pack-catalog_route_actions_1b60gv8.js.map