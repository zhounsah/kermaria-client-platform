module.exports=[65857,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_health_live_route_actions_1xllmwu.js.map