module.exports=[23310,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_invoices_page_actions_09g2urs.js.map