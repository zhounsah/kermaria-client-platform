module.exports=[64970,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_auth_me_route_actions_0yo3hzs.js.map