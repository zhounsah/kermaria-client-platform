module.exports=[64213,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_commercial-documents_%5Bid%5D_issue_route_actions_14g_x_5.js.map