module.exports=[98781,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_admin_commercial-documents_%5Bid%5D_page_actions_1_r_a85.js.map