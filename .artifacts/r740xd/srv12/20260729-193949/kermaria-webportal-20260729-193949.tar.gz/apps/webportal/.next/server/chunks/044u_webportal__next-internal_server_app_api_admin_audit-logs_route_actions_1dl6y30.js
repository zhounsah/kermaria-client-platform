module.exports=[56712,(e,o,d)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_api_admin_audit-logs_route_actions_1dl6y30.js.map