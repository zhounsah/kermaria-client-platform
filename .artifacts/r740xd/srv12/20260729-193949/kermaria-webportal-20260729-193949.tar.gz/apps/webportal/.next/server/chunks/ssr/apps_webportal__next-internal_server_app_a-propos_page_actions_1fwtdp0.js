module.exports=[32057,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_a-propos_page_actions_1fwtdp0.js.map