module.exports=[51286,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_politique-confidentialite_page_actions_1g3zd7j.js.map