module.exports=[30479,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_signups_page_actions_1hen2eq.js.map