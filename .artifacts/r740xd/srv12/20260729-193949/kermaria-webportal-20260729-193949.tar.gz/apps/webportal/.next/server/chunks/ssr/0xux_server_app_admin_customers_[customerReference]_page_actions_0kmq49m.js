module.exports=[30506,(a,b,c)=>{}];

//# sourceMappingURL=0xux_server_app_admin_customers_%5BcustomerReference%5D_page_actions_0kmq49m.js.map