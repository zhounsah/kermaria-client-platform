module.exports=[40360,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_password_page_actions_01997e6.js.map