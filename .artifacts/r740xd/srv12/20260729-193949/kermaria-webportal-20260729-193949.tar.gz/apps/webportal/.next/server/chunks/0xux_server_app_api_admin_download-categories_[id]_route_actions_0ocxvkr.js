module.exports=[19044,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_download-categories_%5Bid%5D_route_actions_0ocxvkr.js.map