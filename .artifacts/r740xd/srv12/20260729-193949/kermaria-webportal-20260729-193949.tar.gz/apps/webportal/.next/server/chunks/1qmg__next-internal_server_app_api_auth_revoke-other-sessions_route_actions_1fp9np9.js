module.exports=[14485,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_auth_revoke-other-sessions_route_actions_1fp9np9.js.map