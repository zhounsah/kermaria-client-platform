module.exports=[85916,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_downloads_%5Bid%5D_route_actions_0e0tkj2.js.map