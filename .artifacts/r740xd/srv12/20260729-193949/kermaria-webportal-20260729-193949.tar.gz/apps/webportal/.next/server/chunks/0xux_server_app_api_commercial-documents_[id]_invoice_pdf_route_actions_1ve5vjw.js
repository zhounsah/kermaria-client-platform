module.exports=[64687,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_commercial-documents_%5Bid%5D_invoice_pdf_route_actions_1ve5vjw.js.map