module.exports=[85587,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_services_page_actions_0a8emtu.js.map