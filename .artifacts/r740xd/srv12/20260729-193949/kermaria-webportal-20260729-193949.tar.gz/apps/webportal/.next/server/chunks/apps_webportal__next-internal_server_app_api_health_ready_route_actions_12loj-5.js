module.exports=[15938,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_health_ready_route_actions_12loj-5.js.map