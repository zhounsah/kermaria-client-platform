module.exports=[2293,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_admin_content_route_actions_1-duadt.js.map