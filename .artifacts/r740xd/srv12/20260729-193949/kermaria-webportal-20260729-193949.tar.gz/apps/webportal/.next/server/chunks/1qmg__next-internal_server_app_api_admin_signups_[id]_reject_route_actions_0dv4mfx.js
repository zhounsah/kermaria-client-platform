module.exports=[98928,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_signups_%5Bid%5D_reject_route_actions_0dv4mfx.js.map