module.exports=[40599,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_set-password_page_actions_0poq23b.js.map