module.exports=[59763,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_catalog_page_actions_0e5qj-2.js.map