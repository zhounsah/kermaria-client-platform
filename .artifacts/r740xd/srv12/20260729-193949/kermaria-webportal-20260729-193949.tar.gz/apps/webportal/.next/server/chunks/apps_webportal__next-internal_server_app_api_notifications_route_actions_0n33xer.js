module.exports=[46766,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_notifications_route_actions_0n33xer.js.map