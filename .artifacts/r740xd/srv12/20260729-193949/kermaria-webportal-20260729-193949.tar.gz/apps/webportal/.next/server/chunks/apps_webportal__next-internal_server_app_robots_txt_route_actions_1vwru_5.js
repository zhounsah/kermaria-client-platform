module.exports=[51305,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_robots_txt_route_actions_1vwru_5.js.map