module.exports=[80843,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_notifications_read-all_route_actions_0m_11ey.js.map