module.exports=[62415,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_payment_paypal_return_route_actions_0koqzmm.js.map