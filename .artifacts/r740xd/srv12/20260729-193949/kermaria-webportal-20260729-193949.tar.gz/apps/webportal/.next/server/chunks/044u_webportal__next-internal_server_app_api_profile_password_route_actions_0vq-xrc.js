module.exports=[72595,(e,o,d)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_api_profile_password_route_actions_0vq-xrc.js.map