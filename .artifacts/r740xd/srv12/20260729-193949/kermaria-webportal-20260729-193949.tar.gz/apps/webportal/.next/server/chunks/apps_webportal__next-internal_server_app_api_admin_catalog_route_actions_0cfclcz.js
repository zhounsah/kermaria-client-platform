module.exports=[18920,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_admin_catalog_route_actions_0cfclcz.js.map