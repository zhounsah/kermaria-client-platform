module.exports=[2900,(a,b,c)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_request-service_%5Bid%5D_page_actions_1nw9jcz.js.map