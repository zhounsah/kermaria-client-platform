module.exports=[24898,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_service-requests_%5Bid%5D_notes_route_actions_09uomp5.js.map