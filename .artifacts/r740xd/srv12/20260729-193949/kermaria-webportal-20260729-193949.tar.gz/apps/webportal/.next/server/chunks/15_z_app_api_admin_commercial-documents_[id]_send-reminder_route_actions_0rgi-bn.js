module.exports=[78198,(e,o,d)=>{}];

//# sourceMappingURL=15_z_app_api_admin_commercial-documents_%5Bid%5D_send-reminder_route_actions_0rgi-bn.js.map