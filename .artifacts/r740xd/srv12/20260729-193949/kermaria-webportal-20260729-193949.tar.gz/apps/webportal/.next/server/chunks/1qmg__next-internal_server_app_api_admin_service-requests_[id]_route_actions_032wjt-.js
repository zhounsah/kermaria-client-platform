module.exports=[20715,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_service-requests_%5Bid%5D_route_actions_032wjt-.js.map