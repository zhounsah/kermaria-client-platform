module.exports=[68468,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_admin_commercial-documents_page_actions_18okf4h.js.map