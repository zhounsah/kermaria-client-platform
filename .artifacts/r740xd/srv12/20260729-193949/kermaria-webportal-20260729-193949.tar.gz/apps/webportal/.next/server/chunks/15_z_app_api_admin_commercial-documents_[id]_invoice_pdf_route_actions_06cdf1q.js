module.exports=[32236,(e,o,d)=>{}];

//# sourceMappingURL=15_z_app_api_admin_commercial-documents_%5Bid%5D_invoice_pdf_route_actions_06cdf1q.js.map