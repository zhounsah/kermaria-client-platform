module.exports=[37345,(a,b,c)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_admin_support-requests_page_actions_1tcla7x.js.map