module.exports=[83343,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_commercial-documents_%5Bid%5D_cancel_route_actions_070k4gr.js.map