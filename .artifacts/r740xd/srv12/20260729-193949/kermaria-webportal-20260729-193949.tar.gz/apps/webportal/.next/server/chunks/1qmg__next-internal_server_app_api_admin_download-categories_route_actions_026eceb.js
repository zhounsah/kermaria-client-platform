module.exports=[56697,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_download-categories_route_actions_026eceb.js.map