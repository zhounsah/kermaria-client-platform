module.exports=[84816,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_set-password_route_actions_1jhvo8h.js.map