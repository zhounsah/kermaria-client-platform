module.exports=[11724,(e,o,d)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_api_admin_activity_route_actions_0iaiuum.js.map