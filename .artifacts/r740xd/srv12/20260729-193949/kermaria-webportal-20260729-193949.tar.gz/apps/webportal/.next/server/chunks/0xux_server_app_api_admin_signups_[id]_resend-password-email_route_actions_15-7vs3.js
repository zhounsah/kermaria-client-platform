module.exports=[19823,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_signups_%5Bid%5D_resend-password-email_route_actions_15-7vs3.js.map