module.exports=[9485,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_commercial-documents_route_actions_0495d58.js.map