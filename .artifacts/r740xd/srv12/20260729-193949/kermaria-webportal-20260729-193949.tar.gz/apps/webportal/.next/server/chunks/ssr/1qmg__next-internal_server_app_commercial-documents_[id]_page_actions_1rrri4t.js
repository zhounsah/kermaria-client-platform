module.exports=[75983,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_commercial-documents_%5Bid%5D_page_actions_1rrri4t.js.map