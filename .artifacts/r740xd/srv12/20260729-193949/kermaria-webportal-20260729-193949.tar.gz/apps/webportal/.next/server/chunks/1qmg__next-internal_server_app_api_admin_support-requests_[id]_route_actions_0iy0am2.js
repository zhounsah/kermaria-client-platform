module.exports=[65162,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_support-requests_%5Bid%5D_route_actions_0iy0am2.js.map