module.exports=[10380,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_page_actions_0sefje-.js.map