module.exports=[32206,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_signups_%5Bid%5D_approve_route_actions_0__f9nu.js.map