module.exports=[61822,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_health_route_actions_1_07l55.js.map