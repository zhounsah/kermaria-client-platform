module.exports=[76572,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_notifications_page_actions_20xzkpv.js.map