module.exports=[58019,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_auth_logout_route_actions_14g7khh.js.map