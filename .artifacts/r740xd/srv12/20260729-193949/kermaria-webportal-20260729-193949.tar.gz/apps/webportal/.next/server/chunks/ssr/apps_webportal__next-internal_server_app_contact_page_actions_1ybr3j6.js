module.exports=[88479,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_contact_page_actions_1ybr3j6.js.map