module.exports=[64278,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_signups_%5Bid%5D_initialize-password_route_actions_0lfvn1n.js.map