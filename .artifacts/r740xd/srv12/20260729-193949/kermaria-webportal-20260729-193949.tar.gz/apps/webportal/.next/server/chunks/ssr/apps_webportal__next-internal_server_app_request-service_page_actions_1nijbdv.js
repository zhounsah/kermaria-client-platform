module.exports=[98004,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_request-service_page_actions_1nijbdv.js.map