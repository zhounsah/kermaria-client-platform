module.exports=[63456,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_commercial-documents_%5Bid%5D_route_actions_0t7sjr9.js.map