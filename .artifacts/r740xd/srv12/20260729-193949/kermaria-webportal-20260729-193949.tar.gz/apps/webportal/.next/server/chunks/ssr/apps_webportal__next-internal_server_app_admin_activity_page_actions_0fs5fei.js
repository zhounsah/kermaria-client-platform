module.exports=[55063,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_activity_page_actions_0fs5fei.js.map