module.exports=[33907,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_commercial-documents_%5Bid%5D_invoice_route_actions_108dgkn.js.map