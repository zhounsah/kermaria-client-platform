module.exports=[71662,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_cgv_page_actions_1zj1mto.js.map