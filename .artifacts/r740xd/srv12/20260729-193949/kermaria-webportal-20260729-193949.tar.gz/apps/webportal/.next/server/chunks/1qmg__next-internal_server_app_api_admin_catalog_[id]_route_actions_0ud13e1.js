module.exports=[81902,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_admin_catalog_%5Bid%5D_route_actions_0ud13e1.js.map