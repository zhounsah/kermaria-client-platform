module.exports=[64934,(e,o,d)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_api_admin_downloads_route_actions_03yod1p.js.map