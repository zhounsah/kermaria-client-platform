module.exports=[7855,(a,b,c)=>{}];

//# sourceMappingURL=0xux_server_app_admin_subscriptions_%5Bid%5D_active-directory_page_actions_0502suy.js.map