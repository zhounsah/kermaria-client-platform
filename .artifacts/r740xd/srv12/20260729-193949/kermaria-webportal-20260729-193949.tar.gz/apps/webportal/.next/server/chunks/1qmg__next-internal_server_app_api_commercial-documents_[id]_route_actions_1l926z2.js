module.exports=[52320,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_commercial-documents_%5Bid%5D_route_actions_1l926z2.js.map