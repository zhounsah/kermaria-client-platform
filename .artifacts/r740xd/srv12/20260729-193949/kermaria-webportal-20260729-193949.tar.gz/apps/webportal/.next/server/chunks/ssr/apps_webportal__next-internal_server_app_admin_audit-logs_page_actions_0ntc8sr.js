module.exports=[42566,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_audit-logs_page_actions_0ntc8sr.js.map