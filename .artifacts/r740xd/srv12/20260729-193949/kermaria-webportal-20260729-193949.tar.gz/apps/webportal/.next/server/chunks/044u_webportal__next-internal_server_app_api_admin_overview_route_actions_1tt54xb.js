module.exports=[21585,(e,o,d)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_api_admin_overview_route_actions_1tt54xb.js.map