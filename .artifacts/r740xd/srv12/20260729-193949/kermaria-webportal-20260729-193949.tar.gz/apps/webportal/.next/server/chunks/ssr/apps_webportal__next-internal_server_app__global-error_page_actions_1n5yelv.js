module.exports=[98026,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app__global-error_page_actions_1n5yelv.js.map