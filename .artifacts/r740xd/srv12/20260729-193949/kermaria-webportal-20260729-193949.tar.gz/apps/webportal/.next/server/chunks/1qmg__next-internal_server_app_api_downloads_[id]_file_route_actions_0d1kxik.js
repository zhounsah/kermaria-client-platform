module.exports=[96835,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_downloads_%5Bid%5D_file_route_actions_0d1kxik.js.map