module.exports=[76867,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_downloads_route_actions_1bb5xea.js.map