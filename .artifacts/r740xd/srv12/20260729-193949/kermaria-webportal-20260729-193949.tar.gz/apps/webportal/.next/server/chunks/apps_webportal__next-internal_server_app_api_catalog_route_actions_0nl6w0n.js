module.exports=[14283,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_catalog_route_actions_0nl6w0n.js.map