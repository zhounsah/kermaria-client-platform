module.exports=[46153,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_admin_subscriptions_%5Bid%5D_page_actions_0b4h47j.js.map