module.exports=[13054,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_sitemap_xml_route_actions_0_k0yze.js.map