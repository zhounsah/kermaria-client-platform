module.exports=[33332,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_commercial-documents_%5Bid%5D_share_route_actions_1qmbewn.js.map