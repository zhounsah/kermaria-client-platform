module.exports=[49712,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_admin_service-requests_%5Bid%5D_page_actions_0cb27nd.js.map