module.exports=[6464,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_profile_page_actions_02my5yq.js.map