module.exports=[39279,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_admin_support-requests_%5Bid%5D_page_actions_1ez0bpg.js.map