module.exports=[24116,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_commercial-documents_%5Bid%5D_lines_route_actions_16t0rkd.js.map