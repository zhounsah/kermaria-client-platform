module.exports=[74973,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_admin_downloads_categories_page_actions_06lalx-.js.map