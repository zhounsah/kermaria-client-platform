module.exports=[74477,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_catalog_%5Bid%5D_page_actions_0awt4zw.js.map