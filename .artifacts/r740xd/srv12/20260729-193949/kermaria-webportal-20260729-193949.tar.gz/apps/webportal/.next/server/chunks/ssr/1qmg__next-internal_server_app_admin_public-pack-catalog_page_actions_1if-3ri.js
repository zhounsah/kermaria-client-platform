module.exports=[5518,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_admin_public-pack-catalog_page_actions_1if-3ri.js.map