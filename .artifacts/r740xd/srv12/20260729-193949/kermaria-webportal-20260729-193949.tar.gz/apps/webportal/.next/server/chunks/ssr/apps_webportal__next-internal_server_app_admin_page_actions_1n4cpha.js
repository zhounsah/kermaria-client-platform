module.exports=[55151,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_page_actions_1n4cpha.js.map