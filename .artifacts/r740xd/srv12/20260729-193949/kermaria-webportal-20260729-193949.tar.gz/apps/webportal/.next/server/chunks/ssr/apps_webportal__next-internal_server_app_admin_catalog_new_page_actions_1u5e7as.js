module.exports=[33398,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_catalog_new_page_actions_1u5e7as.js.map