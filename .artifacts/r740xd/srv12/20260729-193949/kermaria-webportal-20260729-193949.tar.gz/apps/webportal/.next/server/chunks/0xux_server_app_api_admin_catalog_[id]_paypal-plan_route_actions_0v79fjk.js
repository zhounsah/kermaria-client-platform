module.exports=[13075,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_catalog_%5Bid%5D_paypal-plan_route_actions_0v79fjk.js.map