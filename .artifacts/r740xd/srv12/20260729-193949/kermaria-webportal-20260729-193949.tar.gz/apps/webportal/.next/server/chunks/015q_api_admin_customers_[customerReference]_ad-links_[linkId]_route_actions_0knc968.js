module.exports=[12050,(e,o,d)=>{}];

//# sourceMappingURL=015q_api_admin_customers_%5BcustomerReference%5D_ad-links_%5BlinkId%5D_route_actions_0knc968.js.map