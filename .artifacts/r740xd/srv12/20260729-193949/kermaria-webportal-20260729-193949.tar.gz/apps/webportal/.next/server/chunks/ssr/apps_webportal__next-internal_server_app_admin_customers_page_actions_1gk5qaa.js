module.exports=[7993,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_customers_page_actions_1gk5qaa.js.map