module.exports=[19798,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_payments_stripe_return_route_actions_1p2mqxy.js.map