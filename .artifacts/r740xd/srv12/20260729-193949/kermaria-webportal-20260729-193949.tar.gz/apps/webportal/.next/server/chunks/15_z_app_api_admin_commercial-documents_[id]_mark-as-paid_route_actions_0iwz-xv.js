module.exports=[82958,(e,o,d)=>{}];

//# sourceMappingURL=15_z_app_api_admin_commercial-documents_%5Bid%5D_mark-as-paid_route_actions_0iwz-xv.js.map