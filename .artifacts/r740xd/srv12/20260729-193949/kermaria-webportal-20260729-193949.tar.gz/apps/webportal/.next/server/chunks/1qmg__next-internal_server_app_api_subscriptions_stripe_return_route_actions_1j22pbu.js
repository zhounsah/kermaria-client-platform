module.exports=[12673,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_subscriptions_stripe_return_route_actions_1j22pbu.js.map