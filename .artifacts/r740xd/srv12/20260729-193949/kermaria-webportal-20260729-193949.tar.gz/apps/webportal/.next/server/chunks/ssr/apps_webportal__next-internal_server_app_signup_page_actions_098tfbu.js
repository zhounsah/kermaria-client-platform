module.exports=[4661,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_signup_page_actions_098tfbu.js.map