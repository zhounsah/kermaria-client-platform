module.exports=[66128,(e,o,d)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_api_signup_route_actions_1t5etul.js.map