module.exports=[65022,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_offres_page_actions_1utc146.js.map