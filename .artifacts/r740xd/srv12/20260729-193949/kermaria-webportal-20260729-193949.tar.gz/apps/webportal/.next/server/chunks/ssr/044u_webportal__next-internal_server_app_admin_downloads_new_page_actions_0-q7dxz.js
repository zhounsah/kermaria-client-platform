module.exports=[7887,(a,b,c)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_admin_downloads_new_page_actions_0-q7dxz.js.map