module.exports=[32392,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_offres_%5Bslug%5D_page_actions_1-jbhpq.js.map