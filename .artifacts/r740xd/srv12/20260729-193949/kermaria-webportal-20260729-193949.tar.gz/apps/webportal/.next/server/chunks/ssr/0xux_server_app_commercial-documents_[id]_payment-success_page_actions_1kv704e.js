module.exports=[72206,(a,b,c)=>{}];

//# sourceMappingURL=0xux_server_app_commercial-documents_%5Bid%5D_payment-success_page_actions_1kv704e.js.map