module.exports=[77144,(a,b,c)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_admin_commercial-documents_new_page_actions_1kbjfvs.js.map