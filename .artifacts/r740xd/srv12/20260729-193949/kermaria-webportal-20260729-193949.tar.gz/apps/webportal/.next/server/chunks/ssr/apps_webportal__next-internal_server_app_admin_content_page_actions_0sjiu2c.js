module.exports=[22364,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_admin_content_page_actions_0sjiu2c.js.map