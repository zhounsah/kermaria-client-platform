module.exports=[72928,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_support_%5Bid%5D_page_actions_1nxkuew.js.map