module.exports=[32951,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_downloads_page_actions_1e5w3ws.js.map