module.exports=[959,(e,o,d)=>{}];

//# sourceMappingURL=0xux_server_app_api_admin_subscriptions_%5Bid%5D_cancel_route_actions_1dr67n6.js.map