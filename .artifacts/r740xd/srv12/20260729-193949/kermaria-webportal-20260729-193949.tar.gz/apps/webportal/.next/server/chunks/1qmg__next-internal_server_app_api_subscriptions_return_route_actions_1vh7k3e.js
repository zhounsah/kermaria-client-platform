module.exports=[53779,(e,o,d)=>{}];

//# sourceMappingURL=1qmg__next-internal_server_app_api_subscriptions_return_route_actions_1vh7k3e.js.map