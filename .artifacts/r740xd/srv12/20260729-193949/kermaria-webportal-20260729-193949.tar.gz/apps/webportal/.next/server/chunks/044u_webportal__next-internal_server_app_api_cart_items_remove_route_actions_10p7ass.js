module.exports=[15837,(e,o,d)=>{}];

//# sourceMappingURL=044u_webportal__next-internal_server_app_api_cart_items_remove_route_actions_10p7ass.js.map