module.exports=[61579,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_dashboard_page_actions_04ndne_.js.map