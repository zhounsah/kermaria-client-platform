module.exports=[52946,(a,b,c)=>{}];

//# sourceMappingURL=apps_webportal__next-internal_server_app_login_page_actions_0xqbcw_.js.map